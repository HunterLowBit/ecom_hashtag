# ecom_hashtag

 Hashtag

Objetivo:

1. Speedrun de codigo baseado no curso da hashtag
2. Entregar o mais rapido possivel
3. não destruir o codigo antes de entregar
4. não falhar(opcicional)
5. rodar em outras maquinas(opcional?)
6. documentar o codigo se der tempo
7. todo o resto acima em qualquer ordem, de preferencia todos
